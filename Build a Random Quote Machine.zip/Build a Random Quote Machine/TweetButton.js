import React from 'react';

const TweetButton = ({ quote, author }) => {
  const tweetURL = `https://twitter.com/intent/tweet?text=${encodeURIComponent(
    `"${quote}" - ${author}`
  )}`;

  return (
    <a
      id="tweet-quote"
      href={tweetURL}
      target="_blank"
      rel="noopener noreferrer"
    >
      Tweet
    </a>
  );
};

export default TweetButton;
