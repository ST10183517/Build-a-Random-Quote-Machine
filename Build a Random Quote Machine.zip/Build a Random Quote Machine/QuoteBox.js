import React, { useState, useEffect } from 'react';
import styled from 'styled-components';

const QuoteBoxContainer = styled.div`
  text-align: center;
  margin: 0 auto;
  max-width: 500px;
  padding: 20px;
`;

const Text = styled.div`
  font-size: 24px;
  margin-bottom: 20px;
`;

const Author = styled.div`
  font-size: 18px;
`;

const QuoteBox = () => {
  const [quote, setQuote] = useState('');
  const [author, setAuthor] = useState('');

  useEffect(() => {
    // Fetch a random quote from an API or use predefined quotes
    const fetchRandomQuote = async () => {
      const response = await fetch('https://api.example.com/random-quote');
      const data = await response.json();
      setQuote(data.quote);
      setAuthor(data.author);
    };

    fetchRandomQuote();
  }, []);

  const getNewQuote = () => {
    fetchRandomQuote();
  };

  return (
    <QuoteBoxContainer id="quote-box">
      <Text id="text">{quote}</Text>
      <Author id="author">- {author}</Author>
      <NewQuoteButton onClick={getNewQuote} />
      <TweetButton quote={quote} author={author} />
    </QuoteBoxContainer>
  );
};

export default QuoteBox;
